# API
import os
from flask import Flask, request, send_file
from flask_restful import Resource, Api
from flask_cors import CORS
from twilio.rest import Client
import db_connector as db
import time

app = Flask(__name__)
api = Api(app)
cors = CORS(app, resources={r"/*": {"origins": "*"}})

#cambiar las variables de configuración
account_sid = 'AC495cb93d4dc9047b189a9821fd73b237' 
auth_token = '90a94f35ad97119886a7fef310412832'

class MESSAGE(Resource):
    def post(self):
        req = request.json
        
        number = request.form['From']
        message_body = request.form['Body'].lower()    
        mensaje =""
                
        client = Client(account_sid, auth_token) 

        if message_body.find("heart rate") == 0:
          #db.create_img(number)
          mensaje = " "+db.find_user(number)+ " esta es la información actual de tus registros"          
          print(number)
          message = client.messages.create (
                                      from_='whatsapp:+14155238886',  
                                      body= mensaje,
                                      media_url=['https://e1d59601d333.ngrok.io/image?number='+number],
                                      to= number
                                  )
        else:        
          try:          
            mensaje = "Hola "+db.find_user(number)+ " puedes pedirme tu Heart Rate por el momento."
            message = client.messages.create (
                                    from_='whatsapp:+14155238886',  
                                    body= mensaje,                                  
                                    to= number
                                )                 

          except:
            mensaje = "No estas registrado. Escribe ->  Nombre:Ruben Raya  <- todo junto por favor"            
            message = client.messages.create (
                                    from_='whatsapp:+14155238886',  
                                    body= mensaje,                                  
                                    to= number
                                )                 
            

class IMAGE(Resource):
    def get(self):        
        number = request.args.get('number')
        number = number.replace(": ","_+")        
        print(number)
        filename = number+'.png'
        return send_file(filename, mimetype='image/png')

api.add_resource(MESSAGE, '/message')  # Route_1
api.add_resource(IMAGE, '/image')  # Route_2

if __name__ == '__main__':
    app.run(port='5013')
